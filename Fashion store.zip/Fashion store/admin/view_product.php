<!DOCTYPE php>
    <php lang="en">
      <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>Admin page</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-lugx-gaming.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="tooplate_style.css">
<!-- CuFon ends -->
<?php
	error_reporting(1);
	if($_REQUEST['log']=='out')
	{
		session_destroy();
		header("location:index.php");
	}
?>
</head>
<body>

<div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
<div class="main">
<header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="index.php" class="logo">
                        <img src="assets/images/logo.png" alt="" style="width: 158px;">
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                    <li><a href="home.php" class="active">Home</a></li>
                      <li><a href="view_product.php">View Product</a></li>
                      <li><a href="insert_product.php">Add Product</a></li>
                      <li><a href="view_order.php">View Order</a></li>
                      <li><a href="feedback.php">Feedback</a></li>
                      <li><a href="?log=out">Log Out</a></li>
                  </ul>   
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
  </header>

  
  <div class="main-banner">
    <div class="container">
      <div class="row">
      <?php
				error_reporting(1);
	
				include("dbconnect.php");
	
				$view = "SELECT * FROM product";
				$result = mysqli_query($con, $view);
				
				echo "<table border='1' cellspacing='0' cellpadding='5px'>";
				echo "<tr>
						    <th>Product id</th>
					  	  <th>Product brands</th>
					  	  <th>Product model</th>
					  	  <th>Product price</th>
					  	  <th>Product image</th>
					  </tr>
					 ";
				
				while(list($p_id, $p_brands, $p_model, $p_price, $p_img) = mysqli_fetch_array($result))
				{
					echo "<tr align='center'>";
					echo "<td>". $p_id ."</td>";
					echo "<td>". $p_brands ."</td>";
					echo "<td>". $p_model ."</td>";
					echo "<td>". $p_price ."</td>";
					echo "<td>"."<img src='product_images/$p_img' width='80px' height='70px'"."</td>";
					
					echo "<td>"."<a href='delete.php?pro_id=$p_id & pro_img=$p_img'>Delete</a>"."</td>";
				    echo "</tr>";
				}
				echo "</table>";
		  ?>
      </div>
    </div>
  </div>

  <div class="features">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-6">
          <a href="view_product.php">
            <div class="item">
              <div class="image">
                <img src="assets/images/feature-01.png" alt="" style="max-width: 70px;">
              </div>
              <h4>View Product</h4>
            </div>
          </a>
        </div>
        <div class="col-lg-3 col-md-6">
          <a href="view_order.php">
            <div class="item">
              <div class="image">
                <img src="assets/images/feature-02.png" alt="" style="max-width: 70px;">
              </div>
              <h4>View Order</h4>
            </div>
          </a>
        </div>
        <div class="col-lg-3 col-md-6">
          <a href="feedback.php">
            <div class="item">
              <div class="image">
                <img src="assets/images/feature-03.png" alt="" style="max-width: 70px;">
              </div>
              <h4>Feedback</h4>
            </div>
          </a>
        </div>
        <div class="col-lg-3 col-md-6">
          <a href="?log=out">
            <div class="item">
              <div class="image">
                <img src="assets/images/feature-04.png" alt="" style="max-width: 70px;">
              </div>
              <h4>Log Out</h4>
            </div>
          </a>
        </div>
      </div>
    </div>
  </div>
  
  <footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2048 LUGX Gaming Company. All rights reserved. &nbsp;&nbsp; <a rel="nofollow" href="https://templatemo.com" target="_blank">Design: TemplateMo</a></p>
      </div>
    </div>
  </footer>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/counter.js"></script>
  <script src="assets/js/custom.js"></script>

</div>
</body>
</html>
